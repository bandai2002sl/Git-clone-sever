export class CreateTestAuthDto {}
